This page describes the business processes included in the WHO Digital
Adaptation Kit (DAK) HIV (link forthcoming). 
For full details, see the published DAK content.

A business process, or process, is a set of related activities or tasks 
performed together to achieve the objectives of the health programme area, 
such as registration, counselling, referrals. Workflows are a visual 
representation of the progression of activities (tasks, events, interactions) 
that are performed within the business process. The workflow provides a “story” 
for the business process being diagrammed and is used to enhance communication 
and collaboration among users, stakeholders and engineers.

The DAK for HIV focuses on key business processes <mark>insert content here</mark>.

### Overview of Key Business Processes 
The following table describes the workflows of the included processes. 

<table border="1" class="dataframe table table-striped table-bordered">
  <thead>
    <tr class="header">
      <th><strong>#</strong> </th>
      <th><strong>Process Name</strong> </th>
      <th><strong>Process ID</strong> </th>
      <th><strong>Personas</strong> </th>
      <th><strong>Objectives</strong> </th>
    </tr>
 </thead>
 <tbody>
    <tr class="odd">
      <td></td>
      <td>Title </td>
      <td>ID used to reference this process throughout the DAK </td>
      <td>Individuals interacting to complete the process </td>
      <td>A concrete statement describing what the process seeks to achieve </td>
    </tr>
  </tbody>
</table>

### Workflows
The workflows that follow depict processes that have been generalized across different contexts and may not reflect the variability and nuances across different settings. The simplicity of the workflow may not adequately illustrate the nonlinear steps that may occur.

#### Overview of key HIV process flows
The business processes included in the DAK are shown in the following figure. Processes included in the DAK start with a letter (e.g. "A.") and are shown using the "Activity with sub-process" shape, which includes a plus sign. 
